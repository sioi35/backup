package com.afd.company.mypage;

public class ProfileEditOk {

}
