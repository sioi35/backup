package com.test.question.q18;

public class MainClass {

	public static void main(String[] args) throws Exception {
		
		// 탭 전환
		// Ctrl + Tab

		// 작업 히스토리 전환
		// Alt + 좌, 우 바얗ㅇ
		Note2 note = new Note2();
		
		note.setSize("B3");
		note.setColor("노란색");
		note.setPage(25);
		note.setOwner("홍길동");
		System.out.println(note.info1());;
		
		
		
		
//		Note note = new Note();
//		
//		note.setSize("B3");
//		note.setColor("노란색");
//		note.setPage(25);
//		note.setName("홍길동");
//		note.Info();
//		
//		Note note2 = new Note();
//		
//		note2.setSize("A3");
//		note2.setColor("검정색");
//		note2.setPage(100);
//		note2.Info();
//		
//		Note note3 = new Note();
//		
//		note3.setSize("B5");
//		note3.setColor("파란색");
//		note3.setName("아무개");
//		note3.setPage(125);
//		note3.Info();
		
		
		
		
		
		
	}//main
	
}//MainClass
