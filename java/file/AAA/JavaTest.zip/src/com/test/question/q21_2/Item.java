package com.test.question.q21_2;

public class Item {

	private String name; //이름
	private String expiration; //유통기한
	
	// name Getter, Setter
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	//expiration Getter, Setter
	public String getExpiration() {
		return expiration;
	}
	public void setExpiration(String expiration) {
		this.expiration = expiration;
	}
	
}//Item
