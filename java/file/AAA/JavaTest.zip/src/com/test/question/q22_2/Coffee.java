package com.test.question.q22_2;

public class Coffee {
	
	static int bean;
	
	 static int water;
	
	 static int ice;
	
	 static int milk;
	
	 static int beanUnitPrice = 1;
	
	 static double waterUnitPrice = 0.2;
	 
	 static int iceUnitPrice = 3;
	
	 static int milkUnitPrice = 4;
	
	 static int beanTotalPrice;
	
	 static double waterTotalPrice;
	
	 static int iceTotalPrice;
	
	 static int milkTotalPrice;
	
	 static int americano;
	
	 static int latte;
	
	 static int espresso;
	
	
}//Coffee
