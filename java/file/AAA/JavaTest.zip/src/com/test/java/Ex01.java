package com.test.java;

public class Ex01 {

	public static void main(String[] args) {
		
		//주석
		// - 컴파일러가 번역을 하지 않는 요소
		// - 개발자가 프로그래밍 코드와 상관없이 여러가지 내용을 작성하고 싶을 때
		// - 코드 가독성 향상, 전달력 향상, 팀작업 향상
		
		//: 주석, Comment, 단일 라인 주석
		
		/* 주석, Comment 
		다중 라인 주석
		*/
		
	}
	
}